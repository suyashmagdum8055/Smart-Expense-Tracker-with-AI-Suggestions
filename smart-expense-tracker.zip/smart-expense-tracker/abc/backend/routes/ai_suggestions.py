from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, User, Expense, Budget, AISuggestion
from utils.ai_engine import generate_ai_suggestions, get_budget_recommendations
from datetime import datetime

ai_bp = Blueprint('ai', __name__)

@ai_bp.route('/suggestions', methods=['GET'])
@jwt_required()
def get_suggestions():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    expenses = Expense.query.filter_by(user_id=user_id).all()
    budgets = Budget.query.filter_by(user_id=user_id,
                                      month=datetime.now().month,
                                      year=datetime.now().year).all()

    suggestions = generate_ai_suggestions(user, expenses, budgets, db)

    # Save to DB
    for s in suggestions:
        obj = AISuggestion(
            user_id=user_id,
            suggestion=s['text'],
            suggestion_type=s['type']
        )
        db.session.add(obj)
    db.session.commit()

    return jsonify(suggestions)


@ai_bp.route('/recommendations', methods=['GET'])
@jwt_required()
def get_recommendations():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    expenses = Expense.query.filter_by(user_id=user_id).all()
    recs = get_budget_recommendations(user, expenses, float(user.monthly_income or 0))
    return jsonify(recs)


@ai_bp.route('/history', methods=['GET'])
@jwt_required()
def suggestion_history():
    user_id = get_jwt_identity()
    suggestions = AISuggestion.query.filter_by(user_id=user_id)\
        .order_by(AISuggestion.created_at.desc()).limit(20).all()
    return jsonify([s.to_dict() for s in suggestions])
