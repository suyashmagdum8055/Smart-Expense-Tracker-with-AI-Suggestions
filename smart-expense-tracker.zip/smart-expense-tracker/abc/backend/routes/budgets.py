from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, Budget
from datetime import datetime

budgets_bp = Blueprint('budgets', __name__)

@budgets_bp.route('/', methods=['GET'])
@jwt_required()
def get_budgets():
    user_id = get_jwt_identity()
    month = request.args.get('month', datetime.now().month, type=int)
    year = request.args.get('year', datetime.now().year, type=int)
    budgets = Budget.query.filter_by(user_id=user_id, month=month, year=year).all()
    return jsonify([b.to_dict() for b in budgets])


@budgets_bp.route('/', methods=['POST'])
@jwt_required()
def set_budget():
    user_id = get_jwt_identity()
    data = request.get_json()
    month = data.get('month', datetime.now().month)
    year = data.get('year', datetime.now().year)

    # Upsert budget
    budget = Budget.query.filter_by(
        user_id=user_id,
        category_id=data['category_id'],
        month=month, year=year
    ).first()

    if budget:
        budget.amount = data['amount']
    else:
        budget = Budget(
            user_id=user_id,
            category_id=data['category_id'],
            amount=data['amount'],
            month=month, year=year
        )
        db.session.add(budget)

    db.session.commit()
    return jsonify(budget.to_dict()), 201


@budgets_bp.route('/<budget_id>', methods=['DELETE'])
@jwt_required()
def delete_budget(budget_id):
    user_id = get_jwt_identity()
    budget = Budget.query.filter_by(id=budget_id, user_id=user_id).first_or_404()
    db.session.delete(budget)
    db.session.commit()
    return jsonify({'message': 'Budget deleted'})
