from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, Expense, Category
from datetime import datetime, date

expenses_bp = Blueprint('expenses', __name__)

@expenses_bp.route('/', methods=['GET'])
@jwt_required()
def get_expenses():
    user_id = get_jwt_identity()
    month = request.args.get('month', type=int)
    year = request.args.get('year', type=int)

    query = Expense.query.filter_by(user_id=user_id)
    if month and year:
        query = query.filter(
            db.extract('month', Expense.date) == month,
            db.extract('year', Expense.date) == year
        )
    expenses = query.order_by(Expense.date.desc()).all()
    return jsonify([e.to_dict() for e in expenses])


@expenses_bp.route('/', methods=['POST'])
@jwt_required()
def add_expense():
    user_id = get_jwt_identity()
    data = request.get_json()

    if not data or 'amount' not in data:
        return jsonify({'error': 'Amount is required'}), 400

    expense = Expense(
        user_id=user_id,
        amount=data['amount'],
        description=data.get('description', ''),
        category_id=data.get('category_id'),
        payment_method=data.get('payment_method', 'cash'),
        date=datetime.strptime(data['date'], '%Y-%m-%d').date() if 'date' in data else date.today()
    )
    db.session.add(expense)
    db.session.commit()
    return jsonify(expense.to_dict()), 201


@expenses_bp.route('/<expense_id>', methods=['PUT'])
@jwt_required()
def update_expense(expense_id):
    user_id = get_jwt_identity()
    expense = Expense.query.filter_by(id=expense_id, user_id=user_id).first_or_404()
    data = request.get_json()

    for field in ['amount', 'description', 'category_id', 'payment_method']:
        if field in data:
            setattr(expense, field, data[field])
    if 'date' in data:
        expense.date = datetime.strptime(data['date'], '%Y-%m-%d').date()

    db.session.commit()
    return jsonify(expense.to_dict())


@expenses_bp.route('/<expense_id>', methods=['DELETE'])
@jwt_required()
def delete_expense(expense_id):
    user_id = get_jwt_identity()
    expense = Expense.query.filter_by(id=expense_id, user_id=user_id).first_or_404()
    db.session.delete(expense)
    db.session.commit()
    return jsonify({'message': 'Deleted successfully'})


@expenses_bp.route('/summary', methods=['GET'])
@jwt_required()
def get_summary():
    user_id = get_jwt_identity()
    month = request.args.get('month', datetime.now().month, type=int)
    year = request.args.get('year', datetime.now().year, type=int)

    expenses = Expense.query.filter_by(user_id=user_id).filter(
        db.extract('month', Expense.date) == month,
        db.extract('year', Expense.date) == year
    ).all()

    total = sum(float(e.amount) for e in expenses)
    by_category = {}
    for e in expenses:
        cat = e.category.name if e.category else 'Other'
        by_category[cat] = by_category.get(cat, 0) + float(e.amount)

    return jsonify({
        'total': total,
        'count': len(expenses),
        'by_category': by_category,
        'month': month,
        'year': year
    })
