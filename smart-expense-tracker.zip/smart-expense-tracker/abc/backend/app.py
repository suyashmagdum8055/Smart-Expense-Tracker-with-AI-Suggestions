import os
from flask import Flask, jsonify, send_from_directory
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from config import Config
from models import db

# Absolute path to the frontend folder (one level up from backend/)
BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.normpath(os.path.join(BASE_DIR, '..', 'frontend'))

print(f"[INFO] Serving frontend from: {FRONTEND_DIR}")

# Do NOT set static_folder here — we handle everything manually
app = Flask(__name__, static_folder=None)
app.config.from_object(Config)

# Extensions
db.init_app(app)
jwt = JWTManager(app)
CORS(app, origins=["*"], supports_credentials=True)

# ── Register API Blueprints ──────────────────
from routes.auth           import auth_bp
from routes.expenses       import expenses_bp
from routes.budgets        import budgets_bp
from routes.ai_suggestions import ai_bp

app.register_blueprint(auth_bp,     url_prefix='/api/auth')
app.register_blueprint(expenses_bp, url_prefix='/api/expenses')
app.register_blueprint(budgets_bp,  url_prefix='/api/budgets')
app.register_blueprint(ai_bp,       url_prefix='/api/ai')

# ── API utility routes ───────────────────────
@app.route('/api/health')
def health():
    return jsonify({'status': 'ok', 'message': 'Smart Expense Tracker API is running!'})

from models import Category
@app.route('/api/categories')
def get_categories():
    cats = Category.query.filter_by(is_default=True).all()
    return jsonify([c.to_dict() for c in cats])

# ── Serve HTML pages ─────────────────────────
@app.route('/')
def serve_index():
    return send_from_directory(FRONTEND_DIR, 'index.html')

@app.route('/dashboard')
def serve_dashboard():
    return send_from_directory(FRONTEND_DIR, 'dashboard.html')

@app.route('/expenses')
def serve_expenses():
    return send_from_directory(FRONTEND_DIR, 'expenses.html')

@app.route('/budgets')
def serve_budgets():
    return send_from_directory(FRONTEND_DIR, 'budgets.html')

@app.route('/reports')
def serve_reports():
    return send_from_directory(FRONTEND_DIR, 'reports.html')

# ── Serve ALL static files (JS, CSS, images) ─
# This catches /js/api.js, /css/style.css, etc.
@app.route('/<path:filename>')
def serve_static(filename):
    filepath = os.path.join(FRONTEND_DIR, filename)
    if os.path.isfile(filepath):
        return send_from_directory(FRONTEND_DIR, filename)
    # If file not found, send back index.html (SPA fallback)
    return send_from_directory(FRONTEND_DIR, 'index.html')

# ── Entry point ──────────────────────────────
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("\n Database tables ready")
        print(f"  Open your app at:  http://localhost:5000\n")
    app.run(debug=True, host='0.0.0.0', port=5000)
