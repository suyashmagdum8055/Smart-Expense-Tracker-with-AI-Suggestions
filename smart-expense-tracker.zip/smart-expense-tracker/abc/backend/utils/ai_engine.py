from datetime import datetime, timedelta
from sqlalchemy import func

def generate_ai_suggestions(user, expenses, budgets, db):
    """
    Rule-based AI engine that analyzes spending patterns
    and generates smart budget suggestions.
    """
    suggestions = []
    now = datetime.now()
    current_month = now.month
    current_year = now.year

    # --- Group expenses by category this month ---
    monthly_spending = {}
    for exp in expenses:
        if exp.date.month == current_month and exp.date.year == current_year:
            cat = exp.category.name if exp.category else 'Other'
            monthly_spending[cat] = monthly_spending.get(cat, 0) + float(exp.amount)

    total_monthly = sum(monthly_spending.values())
    income = float(user.monthly_income or 0)

    # --- Rule 1: Over-budget warning ---
    budget_map = {b.category.name: float(b.amount) for b in budgets if b.category}
    for cat, spent in monthly_spending.items():
        if cat in budget_map and spent > budget_map[cat]:
            over = spent - budget_map[cat]
            suggestions.append({
                'text': f"⚠️ You've exceeded your {cat} budget by ₹{over:,.0f} this month. Consider reducing {cat} spending next month.",
                'type': 'warning'
            })

    # --- Rule 2: Savings rate ---
    if income > 0:
        savings_rate = ((income - total_monthly) / income) * 100
        if savings_rate < 20:
            suggestions.append({
                'text': f"💡 Your savings rate is {savings_rate:.1f}%. Financial experts recommend saving at least 20% of income. Try cutting discretionary spending.",
                'type': 'tip'
            })
        elif savings_rate >= 40:
            suggestions.append({
                'text': f"🌟 Great job! You're saving {savings_rate:.1f}% of your income this month. Consider investing the surplus.",
                'type': 'positive'
            })

    # --- Rule 3: Top spending category ---
    if monthly_spending:
        top_cat = max(monthly_spending, key=monthly_spending.get)
        top_amount = monthly_spending[top_cat]
        if income > 0 and (top_amount / income) > 0.3:
            suggestions.append({
                'text': f"📊 {top_cat} accounts for {(top_amount/income*100):.0f}% of your income (₹{top_amount:,.0f}). This seems high — review if you can reduce it.",
                'type': 'insight'
            })

    # --- Rule 4: No budget set ---
    unbudgeted = [cat for cat in monthly_spending if cat not in budget_map]
    if unbudgeted:
        cats = ', '.join(unbudgeted[:3])
        suggestions.append({
            'text': f"📋 You have spending in {cats} with no budget set. Setting budgets helps you stay on track!",
            'type': 'suggestion'
        })

    # --- Rule 5: 50/30/20 Rule ---
    if income > 0:
        needs_cats = ['Food & Dining', 'Transport', 'Healthcare', 'Utilities']
        wants_cats = ['Entertainment', 'Shopping']
        needs = sum(monthly_spending.get(c, 0) for c in needs_cats)
        wants = sum(monthly_spending.get(c, 0) for c in wants_cats)

        if (needs / income) > 0.5:
            suggestions.append({
                'text': f"🏠 Your 'needs' spending ({needs/income*100:.0f}% of income) exceeds the recommended 50%. Look for ways to reduce essential costs.",
                'type': 'warning'
            })
        if (wants / income) > 0.3:
            suggestions.append({
                'text': f"🎯 Your 'wants' spending ({wants/income*100:.0f}% of income) is above the 30% guideline. Trim entertainment or shopping to save more.",
                'type': 'tip'
            })

    # --- Default suggestion if no data ---
    if not suggestions:
        suggestions.append({
            'text': "✅ Your spending looks balanced this month! Keep tracking your expenses for personalized insights.",
            'type': 'positive'
        })

    return suggestions


def get_budget_recommendations(user, expenses, income):
    """Generate recommended budget amounts per category based on income."""
    if not income or income <= 0:
        return {}

    # Standard allocation percentages
    recommendations = {
        'Food & Dining': 0.15,
        'Transport': 0.10,
        'Shopping': 0.08,
        'Entertainment': 0.05,
        'Healthcare': 0.05,
        'Utilities': 0.07,
        'Education': 0.05,
        'Savings': 0.20,
        'Other': 0.05
    }
    return {cat: round(income * pct) for cat, pct in recommendations.items()}
