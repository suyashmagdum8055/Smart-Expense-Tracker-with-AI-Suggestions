// api.js — Central API helper for all backend calls
const API_BASE = 'http://localhost:5000/api';

function getToken() {
    return localStorage.getItem('token');
}

async function apiCall(endpoint, method = 'GET', body = null) {
    const headers = { 'Content-Type': 'application/json' };
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const options = { method, headers };
    if (body) options.body = JSON.stringify(body);

    try {
        const res = await fetch(`${API_BASE}${endpoint}`, options);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'API error');
        return data;
    } catch (err) {
        console.error(`[API Error] ${method} ${endpoint}:`, err.message);
        throw err;
    }
}

// Auth
const Auth = {
    login: (email, password) => apiCall('/auth/login', 'POST', { email, password }),
    register: (name, email, password, monthly_income) =>
        apiCall('/auth/register', 'POST', { name, email, password, monthly_income }),
    me: () => apiCall('/auth/me'),
    update: (data) => apiCall('/auth/update', 'PUT', data),
    logout: () => { localStorage.removeItem('token'); localStorage.removeItem('user'); window.location.href = 'index.html'; }
};

// Expenses
const Expenses = {
    list: (month, year) => apiCall(`/expenses/?month=${month}&year=${year}`),
    add: (data) => apiCall('/expenses/', 'POST', data),
    update: (id, data) => apiCall(`/expenses/${id}`, 'PUT', data),
    delete: (id) => apiCall(`/expenses/${id}`, 'DELETE'),
    summary: (month, year) => apiCall(`/expenses/summary?month=${month}&year=${year}`)
};

// Budgets
const Budgets = {
    list: (month, year) => apiCall(`/budgets/?month=${month}&year=${year}`),
    set: (data) => apiCall('/budgets/', 'POST', data),
    delete: (id) => apiCall(`/budgets/${id}`, 'DELETE')
};

// Categories
const Categories = {
    list: () => apiCall('/categories')
};

// AI
const AI = {
    suggestions: () => apiCall('/ai/suggestions'),
    recommendations: () => apiCall('/ai/recommendations'),
    history: () => apiCall('/ai/history')
};

// Auth guard — redirect to login if no token
function requireAuth() {
    if (!getToken()) {
        window.location.href = 'index.html';
    }
}

// Load user from localStorage
function getUser() {
    try { return JSON.parse(localStorage.getItem('user')); } catch { return null; }
}

// Set user in localStorage
function setUser(user) {
    localStorage.setItem('user', JSON.stringify(user));
}

// Format currency (Indian Rupees)
function formatCurrency(amount) {
    return '₹' + Number(amount).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

// Get current month/year
function getCurrentMonthYear() {
    const now = new Date();
    return { month: now.getMonth() + 1, year: now.getFullYear() };
}

// Month names
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
